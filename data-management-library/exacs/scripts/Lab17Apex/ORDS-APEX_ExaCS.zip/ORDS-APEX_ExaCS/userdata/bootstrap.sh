#!/bin/bash
echo "Launch Date : `date`" > /home/opc/launch.txt
echo "Launched with Terraform" >> /home/opc/launch.txt

