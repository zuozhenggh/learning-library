package oracle.demo;

import oracle.ArgParser;

public class FillProducts {
    public static void main(String[] args) { new Main(new ArgParser(args)).fillProducts(); }
}
