cd ~
ORACLE_HOME=$HOME; export ORACLE_HOME
TNS_ADMIN=$HOME/network/admin ; export TNS_ADMIN
echo Running bemchmark 2
sqlplus /nolog @devlivelab3.sql
