-- ====================================================
-- Set these variables to match the details you used to create your instance
--
define ADMIN_USER=ADMIN
define ADMIN_PASSWORD=Ora$Dev$Live2021
define DB_SERVICE=atpdbdesign_tp
set cloudconfig Wallet_ATPDBDESIGN.zip
--
-- ====================================================
