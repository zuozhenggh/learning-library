cd ~
ORACLE_HOME=$HOME; export ORACLE_HOME
TNS_ADMIN=$HOME/network/admin ; export TNS_ADMIN
echo Running bemchmark 1
sqlplus /nolog @devlivelab2.sql
