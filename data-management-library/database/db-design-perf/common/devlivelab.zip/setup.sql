set echo off
set termout off
@@credential.sql
set termout on
set autotrace off
set timing off
set sqlprompt 'SQL> '
set echo off
set feedback on
clear screen
set heading on
set termout on
set define '&'
set tab off
set long 50000
set longchunksize 500
set lines 120
set pages 999


pro
pro Connecting as admin level user
pro
conn &&ADMIN_USER/&&ADMIN_PASSWORD@&&DB_SERVICE
show user
pro
pro Dropping devlive user if it exists
pro

begin
  execute immediate 'drop user devlive cascade';
exception
  when others then
    if sqlcode != -1918 then raise; end if;
end;
/

pro
pro Creating devlive user and allocating privs
pro

create user devlive identified by Ora$Dev$Live2021;

grant resource, connect, unlimited tablespace to devlive;
grant select on v$session_event to devlive;
grant select on v$sesstat to devlive;
grant select on v$statname to devlive;
grant select on v$session to devlive;

pro
pro Testing connection
pro

conn devlive/Ora$Dev$Live2021@&&DB_SERVICE

pro
pro If you got to here with no errors, your DEVLIVE account is ready for schema generation
pro
pro  User    : devlive
pro  Password: Ora$Dev$Live2021
pro
pro Press Enter to continue creating the schema
pause
--
-- ====================================================

set termout on
set echo off
pro Connecting as DEVLIVE and initialising schema

conn devlive/Ora$Dev$Live2021@&&DB_SERVICE

pro Clearing out any existing objects

set termout off
set autotrace off
set timing off
set sqlprompt 'SQL> '
set echo off
set feedback on
clear screen
set heading on
set define '&'
set tab off
set long 50000
set longchunksize 500
set lines 120
set pages 999
undefine 1
undefine 2
undefine 3
undefine 4
alter session set nls_date_format = 'DD-MON-RR';
--
-- baseline, triggers plus indexes plus bad seq
--
drop table perf cascade constraints purge;
drop table results cascade constraints purge;
drop table customers cascade constraints purge;
drop table order_items cascade constraints purge;
drop table orders cascade constraints purge;
drop table product_categories cascade constraints purge;
drop table products cascade constraints purge;

drop sequence customers_seq;
drop sequence product_seq;
drop sequence orders_seq;

set termout on
clear screen
set echo on

create table customers (
    customer_id    integer not null,
    customer_ssn   varchar2(20 char) not null,
    customer_name  varchar2(100 char) not null,
    created_by     varchar2(128) not null
);

alter table customers add constraint customer_pk primary key ( customer_id );
alter table customers add constraint customer_ssn_u unique ( customer_ssn );

create table product_categories (
    category_name varchar2(20) not null
);

alter table product_categories add constraint 
  product_categories_pk primary key ( category_name );
pause
clear screen
create table products (
    product_id                integer not null,
    product_description_json  clob not null check ( product_description_json is json ),
    price                     number not null,
    category_name             varchar2(20) not null,
    product_name              varchar2(100) not null
);
alter table products add constraint products_pk primary key ( product_id );
pause

create table orders (
    order_id        integer not null,
    order_datetime  date not null,
    customer_id     integer not null,
    created_by      varchar2(128) not null
);

alter table orders add constraint order_pk primary key ( order_id );
create index orders_ix1 on orders ( customer_id );
pause
clear screen
create table order_items (
    order_id    integer not null,
    product_id  integer not null,
    quantity    integer not null,
    unit_price  number(10, 2) not null,
    created_by     varchar2(128) not null
);

alter table order_items add constraint order_items_pk 
  primary key ( order_id, product_id );

create index order_items_ix1 on order_items ( order_id );
create index order_items_ix2 on order_items ( product_id );
pause
clear screen
alter table orders
    add constraint order_customer_fk foreign key ( customer_id )
        references customers ( customer_id )
    not deferrable;

alter table order_items
    add constraint order_items_order_fk foreign key ( order_id )
        references orders ( order_id )
    not deferrable;

alter table order_items
    add constraint order_items_products_fk foreign key ( product_id )
        references products ( product_id )
    not deferrable;

alter table products
    add constraint products_product_categories_fk foreign key ( category_name )
        references product_categories ( category_name )
    not deferrable;
pause
clear screen
create sequence customers_seq nocache order;
create sequence product_seq nocache order;
create sequence orders_seq nocache order;
pause
clear screen

create or replace
trigger customer_trg 
before insert on customers
for each row
begin
  if :new.customer_id is null then
     :new.customer_id := customers_seq.nextval;
  end if;
  
  if :new.created_by is null then
     :new.created_by := user;
  end if;
end;
/
pause
clear screen

create or replace
trigger orders_trg 
before insert on orders
for each row
begin
  if :new.order_id is null then
     :new.order_id := orders_seq.nextval;
  end if;

  if :new.order_datetime is null then
     :new.order_datetime := sysdate;
  end if;
  
  if :new.created_by is null then
     :new.created_by := user;
  end if;
end;
/
pause
clear screen
create or replace
trigger order_items_trg 
before insert on order_items
for each row
begin
  if :new.created_by is null then
     :new.created_by := user;
  end if;
end;
/
pause
clear screen
--
-- Populating some seed data
--

insert into customers ( customer_ssn ,customer_name )
select 'custssn'||rownum, 'customer'||rownum
from dual
connect by level <= 5000;
pause

insert into product_categories
select 'cat'||rownum
from dual
connect by level <= 20;
pause

insert into products 
select rownum,
       '{"product":"my product'||rownum||'"}',
       round(dbms_random.value(10,40),2),
       'cat'||(mod(rownum,20)+1),
       'product'||rownum
from dual
connect by level <= 1000;
commit;
exec dbms_stats.gather_schema_stats('DEVLIVE')
set echo off
col table_name format a30
select table_name, num_rows
from   all_tables
where  owner = 'DEVLIVE';
pro
pro Schema generation complete
pro
pro Press Enter to exit
pause
exit
