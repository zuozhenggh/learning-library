set echo off
set termout off
@@credential.sql
set termout on
clear screen
conn devlive/Ora$Dev$Live2021@&&DB_SERVICE
set feedback off
variable mysid number
exec :mysid := to_number(sys_context('USERENV','SID'));

set feedback on
set echo on
select sys_context('USERENV','INSTANCE') from dual;
set serverout on
exec benchmark&1..init(&1)

select seed
from results 
where seed = &1
for update;

exec benchmark&1..run(&1)

insert into perf
select &1, x.* from 
(
  select EVENT
  ,TOTAL_WAITS
  ,TOTAL_TIMEOUTS
  ,SECS
  ,rpad(to_char(100 * ratio_to_report(secs) over (), 'FM00.00') || '%',8)  pct
  from (
  select EVENT
  ,TOTAL_WAITS
  ,TOTAL_TIMEOUTS
  ,TIME_WAITED/100 SECS
  from v$session_event
  where sid = :mysid
  and event not like 'SQL*Net%'
  and event != 'enq: TM - contention'
  union all
  select 'CPU', null, null, value/100 from v$sesstat 
  where statistic# = ( select statistic# from v$statname where name = 'CPU used by this session') 
  and sid = :mysid
)) x
where pct not like '00.00%';
commit;

host sleep 5
exit

