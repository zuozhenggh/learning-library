cd ~
if ! ls Wallet*zip >/dev/null 2>&1; then
  echo Could not find wallet file
  exit 1
fi
mkdir -p network/admin
cd network/admin
echo Unzipping wallet for sqlplus usage
unzip -oq $HOME/Wallet*zip
ORACLE_HOME=$HOME; export ORACLE_HOME
TNS_ADMIN=$HOME/network/admin ; export TNS_ADMIN
echo Running SQLcl to create user
cd ~
sql /nolog @setup.sql
echo Done
