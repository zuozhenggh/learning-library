set echo off
set termout off
@@credential.sql
set termout on
set echo off
pro Connecting as DEVLIVE and initialising session

conn devlive/Ora$Dev$Live2021@&&DB_SERVICE

pro Clearing out any existing objects 

set termout off
set autotrace off
set timing off
set sqlprompt 'SQL> '
set echo off
set feedback on
set heading on
set define '&'
set tab off
set long 50000
set longchunksize 500
set lines 120
set pages 999
undefine 1
undefine 2
undefine 3
undefine 4
alter session set nls_date_format = 'DD-MON-RR';
--
-- baseline, triggers plus indexes plus bad seq
--
drop table perf cascade constraints purge;
drop table results cascade constraints purge;
drop table customers cascade constraints purge;
drop table order_items cascade constraints purge;
drop table orders cascade constraints purge;
drop table product_categories cascade constraints purge;
drop table products cascade constraints purge;

drop sequence customers_seq;
drop sequence product_seq;
drop sequence orders_seq;

set termout on
pro
pro Rebuilding schema to give a consistent base for each benchmark
pro Please wait...
pro

create table customers (
    customer_id    integer not null,
    customer_ssn   varchar2(20 char) not null,
    customer_name  varchar2(100 char) not null,
    created_by     varchar2(128) not null
);

alter table customers add constraint customer_pk primary key ( customer_id );
alter table customers add constraint customer_ssn_u unique ( customer_ssn );

create table product_categories (
    category_name varchar2(20) not null
);

alter table product_categories add constraint 
  product_categories_pk primary key ( category_name );
create table products (
    product_id                integer not null,
    product_description_json  clob not null check ( product_description_json is json ),
    price                     number not null,
    category_name             varchar2(20) not null,
    product_name              varchar2(100) not null
);
alter table products add constraint products_pk primary key ( product_id );

create table orders (
    order_id        integer not null,
    order_datetime  date not null,
    customer_id     integer not null,
    created_by      varchar2(128) not null
);

alter table orders add constraint order_pk primary key ( order_id );
create index orders_ix1 on orders ( customer_id );
create table order_items (
    order_id    integer not null,
    product_id  integer not null,
    quantity    integer not null,
    unit_price  number(10, 2) not null,
    created_by     varchar2(128) not null
);

alter table order_items add constraint order_items_pk 
  primary key ( order_id, product_id );

create index order_items_ix1 on order_items ( order_id );
create index order_items_ix2 on order_items ( product_id );
alter table orders
    add constraint order_customer_fk foreign key ( customer_id )
        references customers ( customer_id )
    not deferrable;

alter table order_items
    add constraint order_items_order_fk foreign key ( order_id )
        references orders ( order_id )
    not deferrable;

alter table order_items
    add constraint order_items_products_fk foreign key ( product_id )
        references products ( product_id )
    not deferrable;

alter table products
    add constraint products_product_categories_fk foreign key ( category_name )
        references product_categories ( category_name )
    not deferrable;
create sequence customers_seq nocache order;
create sequence product_seq nocache order;
create sequence orders_seq nocache order;

create or replace
trigger customer_trg 
before insert on customers
for each row
begin
  if :new.customer_id is null then
     :new.customer_id := customers_seq.nextval;
  end if;
  
  if :new.created_by is null then
     :new.created_by := user;
  end if;
end;
/
create or replace
trigger orders_trg 
before insert on orders
for each row
begin
  if :new.order_id is null then
     :new.order_id := orders_seq.nextval;
  end if;

  if :new.order_datetime is null then
     :new.order_datetime := sysdate;
  end if;
  
  if :new.created_by is null then
     :new.created_by := user;
  end if;
end;
/
create or replace
trigger order_items_trg 
before insert on order_items
for each row
begin
  if :new.created_by is null then
     :new.created_by := user;
  end if;
end;
/

pro Populating tables with some seed data

insert into customers ( customer_ssn ,customer_name )
select 'custssn'||rownum, 'customer'||rownum
from dual
connect by level <= 5000;

insert into product_categories
select 'cat'||rownum
from dual
connect by level <= 20;

insert into products 
select rownum,
       '{"product":"my product'||rownum||'"}',
       round(dbms_random.value(10,40),2),
       'cat'||(mod(rownum,20)+1),
       'product'||rownum
from dual
connect by level <= 1000;
commit;

exec dbms_stats.gather_schema_stats('DEVLIVE')
col table_name format a30
select table_name, num_rows
from   user_tables;
pro
pro Done. Press Enter to continue
pro
pause
clear screen
pro
pro Now building our "application" on this schema
pro
set echo on
--
-- PLSQL routines to create orders and customers
--
create or replace 
procedure new_order(p_customer_id int, 
                    p_order_id out int) is
begin
  insert into orders ( customer_id)
  values ( p_customer_id)
  returning order_id into p_order_id;
end;
/
pause
create or replace 
procedure new_customer(p_customer_ssn varchar2,
                       p_customer_name varchar2,
                       p_cust_id out int) is
begin
  insert into customers ( customer_ssn ,customer_name )
  values ( p_customer_ssn ,p_customer_name )
  returning customer_id into p_cust_id;
end;
/
pause

create or replace
procedure new_order_item(p_order_id int, p_product_id int, p_quantity int, p_unit_price number ) is
begin
  insert into order_items (order_id,product_id,quantity,unit_price)
  values (p_order_id,p_product_id,p_quantity,p_unit_price);
end;
/
pause
clear screen

--
-- These two tables will be used to initiate our benchmark in a controlled
-- fashion, and capture performance results
--

create table perf (
  seed           int,
  event          varchar2(80),
  total_waits    number,
  total_timeouts number,
  secs           number(10,2),
  pct            varchar2(10)
);
create table results as select rownum-1 seed, 0 tps, 0 ela from dual
connect by level <= 10;

pause
clear screen
--
-- PLSQL package to perform the benchmark
-- 
--  Two key routines: 
--   INIT - setup all the random data in advance so 
--          that is does not interfere with performance
--
--   RUN - go through 'n' iterations of randomised
--         customer and order creation using our 
--         schema and plsql routines
--
--  The two variables 'iter' and 'new_cust' determine
--  volume and can be edited depending on how large a 
--  autonomous database instance you have created. The
--  defaults are chosen for the smallest always-free
--  database
--
pause

create or replace 
package benchmark is
  iter     int := 10000;   -- ORDERS TO PLACE
  new_cust int := 200;     -- NEW CUST EVERY 200 ORDERS 

  rnd  int := 50000;
  idx  int;
  seed int;
  l_start number;
  
  l_order_id int;
  l_cust_id int;
  type numlist is table of number
    index by pls_integer;

  type charlist is table of varchar2(20)
    index by pls_integer;
  
  l_cust      numlist;
  l_prod      numlist;
  l_cat       charlist;
  l_item_cnt  numlist;
  l_lock      int;

  procedure init(p_seed int);
  procedure run(p_seed int);
end;
/
pause
clear screen

create or replace 
package body benchmark is

procedure init(p_seed int) is
begin  
  seed := p_seed;
  dbms_random.seed(p_seed*10);
  
  select mod(rownum,5000)+1 bulk collect into l_cust 
  from dual connect by level <= rnd
  order by dbms_random.value;

  select mod(rownum,1000)+1 bulk collect into l_prod 
  from dual connect by level <= rnd+10
  order by dbms_random.value;

  select 'cat'||(mod(rownum,20)+1) bulk collect into l_cat 
  from dual connect by level <= rnd
  order by dbms_random.value;

  select mod(rownum,10)+1 bulk collect into l_item_cnt 
  from dual connect by level <= rnd
  order by dbms_random.value;
end;

procedure run(p_seed int) is  
begin
  l_start := dbms_utility.get_time;
  for i in 1 .. iter
  loop
    idx := mod(iter,rnd)+1;
    if mod(i,new_cust) = 0 then
       new_customer('ssn'||(i*10+seed),'newname'||(i*10+seed),l_cust_id);
       new_order(l_cust_id, l_order_id);
    else
        new_order(l_cust(idx), l_order_id);
    end if;
    
    for j in 1 .. mod(i,5)+1
    loop
      new_order_item(l_order_id, l_prod(idx+j), j, j );
    end loop;
    commit;
  end loop;
  l_start := mod(dbms_utility.get_time - l_start + power(2,32),power(2,32));
  update results 
    set tps = round(iter / (l_start/100),1),
        ela = l_start/100
  where seed = p_seed;
  commit;
end;

end;
/
pause

clear screen
conn devlive/Ora$Dev$Live2021@&&DB_SERVICE
lock table results in exclusive mode;
--
-- We have locked the results table. Now we are about to fire off
-- 8 concurrent SQL sessions, all which will smash away at the benchmark
-- as hard as they can.  However, to ensure they all start at once, they
-- try to get the same lock as above.  So they will do nothing until
-- we commit from THIS session
--
pause

host ./sql_plus 0
host ./sql_plus 1
host ./sql_plus 2
host ./sql_plus 3
host ./sql_plus 4
host ./sql_plus 5
host ./sql_plus 6
host ./sql_plus 7

REM
REM Nothing starts until you hit enter here which will do a commit
REM
pause
commit;

REM
REM Waiting for benchmark to finish
REM
set echo off
declare
  x int;
begin
  loop
    select count(distinct seed) into x
    from   perf;
    
    exit when x = 8;
    dbms_session.sleep(2);
  end loop;
end;
/
pro
pro All completed!
pro
set echo on
clear screen
set echo off
set lines 200
col event format a44 TRUNC
col pct format a10
select min(ela), max(ela), avg(ela) from results where ela != 0;
select sum(tps) from results;
select * from 
(
  select 
   event
  ,total_waits
  ,total_timeouts
  ,secs
  ,rpad(to_char(100 * ratio_to_report(secs) over (), 'FM00.00') || '%',8)  pct
  from (
    select event
          ,sum(total_waits) total_waits
          ,sum(total_timeouts) total_timeouts
          ,sum(secs) secs
    from devlive.perf
    group by event
))
where pct not like '00.00%'
order by 4;

set echo off
pro
pro Scroll back to take note of the transactions per second (TPS), average elapsed time (ELA)
pro for each session, and how the time was distributed between CPU and contention etc.
pro
pro Our aim is to improve on this without changing the benchmark, just the physical design
pro
pro Script completed.
pro
pro Press Enter to exit
pause
exit

