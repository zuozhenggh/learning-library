set echo off
set termout off
@@credential.sql
set termout on
set echo off
pro Connecting as DEVLIVE and initialising session

conn devlive/Ora$Dev$Live2021@&&DB_SERVICE

pro Clearing out any existing objects


set termout off
set autotrace off
set timing off
set sqlprompt 'SQL> '
set echo off
set feedback on
clear screen
set heading on
set define '&'
set tab off
set long 50000
set longchunksize 500
set lines 120
set pages 999
undefine 1
undefine 2
undefine 3
undefine 4
alter session set nls_date_format = 'DD-MON-RR';
--
-- baseline, triggers plus indexes plus bad seq
--
drop table perf cascade constraints purge;
drop table results cascade constraints purge;
drop table customers cascade constraints purge;
drop table order_items cascade constraints purge;
drop table orders cascade constraints purge;
drop table product_categories cascade constraints purge;
drop table products cascade constraints purge;
create table perf (
  seed           int,
  event          varchar2(80),
  total_waits    number,
  total_timeouts number,
  secs           number(10,2),
  pct            varchar2(10)
);

drop sequence customers_seq;
drop sequence product_seq;
drop sequence orders_seq;

set termout on
clear screen
set echo on

clear screen
set echo on
create sequence customers_seq cache 100;
create sequence product_seq;
create sequence orders_seq cache 5000;

clear screen

create table customers (
    customer_id    integer default on null customers_seq.nextval not null,
    customer_ssn   varchar2(20 char) not null,
    customer_name  varchar2(100 char) not null,
    created_by     varchar2(128) default on null user not null
);

alter table customers add constraint customer_pk primary key ( customer_id );
alter table customers add constraint customer_ssn_u unique ( customer_ssn );

create table product_categories (
    category_name varchar2(20) not null
);

alter table product_categories add constraint product_categories_pk primary key ( category_name );

clear screen

create table products (
    product_id                integer not null,
    product_description_json  clob not null check ( product_description_json is json ),
    price                     number not null,
    category_name             varchar2(20) not null,
    product_name              varchar2(100) not null
);

alter table products add constraint products_pk primary key ( product_id );

clear screen

create table orders (
    order_id        integer default on null orders_seq.nextval not null,
    order_datetime  date default on null sysdate not null,
    customer_id     integer not null,
    created_by      varchar2(128) default on null user not null
) PARTITION BY HASH ( ORDER_ID ) PARTITIONS 16;

alter table orders add constraint order_pk primary key ( order_id )
  using index ( CREATE INDEX ORDER_PK ON ORDERS ( ORDER_ID ) 
                GLOBAL PARTITION BY HASH ( ORDER_ID ) PARTITIONS 16 ) ;

create index orders_ix1 on orders ( customer_id ) local;


clear screen

create table order_items (
    order_id    integer not null,
    product_id  integer not null,
    quantity    integer not null,
    unit_price  number(10, 2) not null,
    created_by     varchar2(128) default on null user  not null
)  PARTITION BY HASH ( ORDER_ID ) PARTITIONS 16;


alter table order_items add constraint order_items_pk 
  primary key ( order_id, product_id ) 
  USING INDEX LOCAL;

clear screen

alter table orders
    add constraint order_customer_fk foreign key ( customer_id )
        references customers ( customer_id )
    not deferrable;

alter table order_items
    add constraint order_items_order_fk foreign key ( order_id )
        references orders ( order_id )
    not deferrable;

alter table order_items
    add constraint order_items_products_fk foreign key ( product_id )
        references products ( product_id )
    not deferrable;

alter table products
    add constraint products_product_categories_fk foreign key ( category_name )
        references product_categories ( category_name )
    not deferrable;

insert into customers ( customer_ssn ,customer_name )
select 'custssn'||rownum, 'customer'||rownum
from dual
connect by level <= 5000;

insert into product_categories
select 'cat'||rownum
from dual
connect by level <= 20;

insert into products 
select rownum,
       '{"product":"my product'||rownum||'"}',
       round(dbms_random.value(10,40),2),
       'cat'||(mod(rownum,20)+1),
       'product'||rownum
from dual
connect by level <= 1000;

commit;



create or replace
procedure new_order_item(p_order_id int, p_product_id int, p_quantity int, p_unit_price number ) is
begin
  insert into order_items (order_id,product_id,quantity,unit_price)
  values (p_order_id,p_product_id,p_quantity,p_unit_price);
end;
/


create table results as select rownum-1 seed, 0 tps, 0 ela from dual
connect by level <= 10;

declare
  l_clob1 clob := 
q'{
create or replace 
package benchmark@@@ is
  seed int;
  iter     int := 10000;  -- ORDERS TO PLACE
  rnd  int := 50000;
  idx  int;
  new_cust int := 200;
  l_start number;
  
  l_order_id int;
  l_cust_id int;
  type numlist is table of number
    index by pls_integer;

  type charlist is table of varchar2(20)
    index by pls_integer;
  
  l_cust      numlist;
  l_prod      numlist;
  l_cat       charlist;
  l_item_cnt  numlist;
  l_lock      int;
  l_prod_ord  numlist;

  procedure init(p_seed int);
  procedure run(p_seed int);
end;}';

  l_clob2 clob := 
q'{create or replace 
package body benchmark@@@ is

procedure init(p_seed int) is
begin  
  seed := p_seed;
  dbms_random.seed(p_seed*10);
  
  select mod(rownum,5000)+1 bulk collect into l_cust 
  from dual connect by level <= rnd
  order by dbms_random.value;

  select mod(rownum,1000)+1 bulk collect into l_prod 
  from dual connect by level <= rnd+10
  order by dbms_random.value;

  select 'cat'||(mod(rownum,20)+1) bulk collect into l_cat 
  from dual connect by level <= rnd
  order by dbms_random.value;

  select mod(rownum,10)+1 bulk collect into l_item_cnt 
  from dual connect by level <= rnd
  order by dbms_random.value;
end;


procedure run(p_seed int) is  
begin
  l_start := dbms_utility.get_time;
  for i in 1 .. iter
  loop
    idx := mod(iter,rnd)+1;
    if mod(i,new_cust) = 0 then
       pragma inline(new_customer@@@,'YES');
       new_customer@@@('ssn'||(i*10+seed),'newname'||(i*10+seed),l_cust_id);
       pragma inline(new_order@@@,'YES');
       new_order@@@(l_cust_id, l_order_id);
    else
       pragma inline(new_order@@@,'YES');
       new_order@@@(l_cust(idx), l_order_id);
    end if;

    for j in 1 .. mod(i,5)+1
    loop
      l_prod_ord(j) := l_prod(idx+j);
    end loop;
    forall j in 1 .. mod(i,5)+1
      insert into order_items (order_id,product_id,quantity,unit_price)
      values (l_order_id,l_prod_ord(j),1,1);
    commit;
  end loop;
  l_start := mod(dbms_utility.get_time - l_start + power(2,32),power(2,32));
  update results 
    set tps = round(iter / (l_start/100),1),
        ela = l_start/100
  where seed = p_seed;
  commit;
end;

end;}';

l_clob3 clob := 
q'{create or replace 
procedure new_order@@@(p_customer_id int, p_order_id out int) is
begin
  insert into orders ( customer_id)
  values ( p_customer_id)
  returning order_id into p_order_id;
end;}';

l_clob4 clob := 
q'{create or replace 
procedure new_customer@@@(p_customer_ssn varchar2,p_customer_name varchar2,p_cust_id out int) is
begin
  insert into customers ( customer_ssn ,customer_name )
  values ( p_customer_ssn ,p_customer_name )
  returning customer_id into p_cust_id;
end;}';


begin
  for i in 0 .. 7 loop
    execute immediate replace(l_clob3,'@@@',i);
    execute immediate replace(l_clob4,'@@@',i);

    execute immediate replace(l_clob1,'@@@',i);
    execute immediate replace(l_clob2,'@@@',i);
  end loop;
end;  
/
pause
clear screen

conn devlive/Ora$Dev$Live2021@&&DB_SERVICE
lock table results in exclusive mode;

host ./sql_plus 0
host ./sql_plus 1
host ./sql_plus 2
host ./sql_plus 3
host ./sql_plus 4
host ./sql_plus 5
host ./sql_plus 6
host ./sql_plus 7
host sleep 10
commit;



REM
REM Waiting for benchmark to finish
REM
set echo off
declare
  x int;
begin
  loop
    select count(distinct seed) into x
    from   perf;
    
    exit when x = 8;
    dbms_session.sleep(2);
  end loop;
end;
/
pro
pro All completed!
pro
set echo on
clear screen
set echo off
set lines 200
col event format a44 TRUNC
col pct format a10
select min(ela), max(ela), avg(ela) from results where ela != 0;
select sum(tps) from results;
select * from 
(
  select 
   event
  ,total_waits
  ,total_timeouts
  ,secs
  ,rpad(to_char(100 * ratio_to_report(secs) over (), 'FM00.00') || '%',8)  pct
  from (
    select event
          ,sum(total_waits) total_waits
          ,sum(total_timeouts) total_timeouts
          ,sum(secs) secs
    from devlive.perf
    group by event
))
where pct not like '00.00%'
order by 4;

