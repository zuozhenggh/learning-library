set echo off
set termout off
@@credential.sql
set termout on

set autotrace off
set timing off
set sqlprompt 'SQL> '
set echo off
set feedback on
clear screen
set heading on
set termout on
set define '&'
set tab off
set long 50000
set longchunksize 500
set lines 120
set pages 999


pro
pro Connecting as admin level user
pro
conn &&ADMIN_USER/&&ADMIN_PASSWORD@&&DB_SERVICE
show user
pro
pro Dropping devlive user if it exists
pro

begin
  execute immediate 'drop user devlive cascade';
exception
  when others then
    if sqlcode != -1918 then raise; end if;
end;
/

pro
pro Creating devlive user and allocating privs
pro

create user devlive identified by Ora$Dev$Live2021;

grant resource, connect, unlimited tablespace to devlive;
grant select on v$session_event to devlive;
grant select on v$sesstat to devlive;
grant select on v$statname to devlive;
grant select on v$session to devlive;

pro
pro Testing connection
pro

conn devlive/Ora$Dev$Live2021@&&DB_SERVICE

pro
pro If you got to here with no errors, your DEVLIVE account is ready to
pro
pro  User    : devlive
pro  Password: Ora$Dev$Live2021
pro
