#!/bin/bash
mount /u01
/u01/ocidb/GenerateNetconfig.sh > /u01/ocidb/netconfig.ini
/u01/ocidb/buildsingle.sh -s