export ORACLE_HOME=/u01/app/oracle/product/19c/dbhome_1; export ORACLE_BASE=/u01/app/oracle; /u01/app/oracle/product/19c/dbhome_1/bin/dbca -silent -createDatabase  -emConfiguration NONE  -templateName 'General_Purpose.dbc' -storageType FS -datafileDestination '/u01/app/oracle/oradata' -useOMF true -datafileJarLocation '/u01/app/oracle/product/19c/dbhome_1/assistants/dbca/templates' -sampleSchema false -oratabLocation /etc/oratab  -runCVUChecks false -continueOnNonFatalErrors true -createAsContainerDatabase true -numberOfPDBs 1 -pdbName pdb1 -gdbName 'CDB1' -sid 'CDB1' -sysPassword oracle -systemPassword oracle -pdbadminPassword oracle -initParams filesystemio_options=setall -ignorePrereqs
sleep 20
export ORACLE_HOME=/u01/app/oracle/product/19c/dbhome_1; export ORACLE_BASE=/u01/app/oracle; /u01/app/oracle/product/19c/dbhome_1/bin/dbca -silent -createDatabase  -emConfiguration NONE  -templateName 'General_Purpose.dbc' -storageType FS -datafileDestination '/u01/app/oracle/oradata' -useOMF true -datafileJarLocation '/u01/app/oracle/product/19c/dbhome_1/assistants/dbca/templates' -sampleSchema false -oratabLocation /etc/oratab  -runCVUChecks false -continueOnNonFatalErrors true -createAsContainerDatabase true -numberOfPDBs 1 -pdbName pdb2 -gdbName 'CDB2' -sid 'CDB2' -sysPassword oracle -systemPassword oracle -pdbadminPassword oracle -initParams filesystemio_options=setall -ignorePrereqs
sleep 20
export ORACLE_BASE=/u01/app/oracle; export ORACLE_HOME=/u01/app/oracle/product/19c/dbhome_1; /u01/app/oracle/product/19c/dbhome_1/bin/netca /orahome /u01/app/oracle/product/19c/dbhome_1 /instype custom /listener "LISTCDB1" /inscomp client,oraclenet,javavm,server,ano /insprtcl tcp /cfg local /authadp NO_VALUE /responseFile /u01/app/oracle/product/19c/dbhome_1/network/install/netca_typ.rsp /lisport 1523 /silent /orahnam OraDB19Home1
sleep 20
export ORACLE_BASE=/u01/app/oracle; export ORACLE_HOME=/u01/app/oracle/product/19c/dbhome_1; /u01/app/oracle/product/19c/dbhome_1/bin/netca /orahome /u01/app/oracle/product/19c/dbhome_1 /instype custom /listener "LISTCDB2" /inscomp client,oraclenet,javavm,server,ano /insprtcl tcp /cfg local /authadp NO_VALUE /responseFile /u01/app/oracle/product/19c/dbhome_1/network/install/netca_typ.rsp /lisport 1524 /silent /orahnam OraDB19Home1
sleep 20

DBHOST=`hostname -I |nslookup|grep "name ="|awk '{print $4}'|sed s/.$//`
export DBHOST
#echo "ORCL = (DESCRIPTION = (ADDRESS = (PROTOCOL = TCP)(HOST = ${DBHOST})(PORT=1523))(CONNECT_DATA = (SERVER = DEDICATED) (SERVICE_NAME = ORCL) ) )" > $ORACLE_HOME/network/admin/tnsnames.ora
#echo "LISTENER_ORCL = (ADDRESS = (PROTOCOL = TCP)(HOST = ${DBHOST})(PORT = 1521))" >> $ORACLE_HOME/network/admin/tnsnames.ora
#echo "ORCLPDB = (DESCRIPTION = (ADDRESS = (PROTOCOL = TCP)(HOST = ${DBHOST})(PORT=1523))(CONNECT_DATA = (SERVER = DEDICATED) (SERVICE_NAME = ORCLPDB) ) )" >> $ORACLE_HOME/network/admin/tnsnames.ora
echo "CDB1 = (DESCRIPTION = (ADDRESS = (PROTOCOL = TCP)(HOST = ${DBHOST})(PORT=1523))(CONNECT_DATA = (SERVER = DEDICATED) (SERVICE_NAME = CDB1) ) )" >> $ORACLE_HOME/network/admin/tnsnames.ora
echo "PDB1 = (DESCRIPTION = (ADDRESS = (PROTOCOL = TCP)(HOST = ${DBHOST})(PORT=1523))(CONNECT_DATA = (SERVER = DEDICATED) (SERVICE_NAME = PDB1) ) )" >> $ORACLE_HOME/network/admin/tnsnames.ora
echo "CDB2 = (DESCRIPTION = (ADDRESS = (PROTOCOL = TCP)(HOST = ${DBHOST})(PORT=1524))(CONNECT_DATA = (SERVER = DEDICATED) (SERVICE_NAME = CDB2) ) )" >> $ORACLE_HOME/network/admin/tnsnames.ora
echo "PDB2 = (DESCRIPTION = (ADDRESS = (PROTOCOL = TCP)(HOST = ${DBHOST})(PORT=1524))(CONNECT_DATA = (SERVER = DEDICATED) (SERVICE_NAME = PDB2) ) )" >> $ORACLE_HOME/network/admin/tnsnames.ora
echo "LISTORCL = (ADDRESS = (PROTOCOL = TCP)(HOST = ${DBHOST})(PORT=1521))" >> $ORACLE_HOME/network/admin/tnsnames.ora
echo "LISTCDB1 = (ADDRESS = (PROTOCOL = TCP)(HOST = ${DBHOST})(PORT=1523))" >> $ORACLE_HOME/network/admin/tnsnames.ora
echo "LISTCDB2 = (ADDRESS = (PROTOCOL = TCP)(HOST = ${DBHOST})(PORT=1524))" >> $ORACLE_HOME/network/admin/tnsnames.ora

sleep 20

ORACLE_SID=CDB1
ORAENV_ASK=NO
. oraenv
sqlplus /nolog <<EOF
connect sys as sysdba
alter system set local_listener='LISTCDB1' scope=both;
create database link cdb2_link connect to system identified by oracle using '(DESCRIPTION = (ADDRESS = (PROTOCOL = TCP)(HOST = localhost)(PORT = 1524)) (CONNECT_DATA = (SERVER = DEDICATED) (SERVICE_NAME = cdb2)))';
grant sysoper to system container=all;
EOF

sleep 20

ORACLE_SID=CDB2
ORAENV_ASK=NO
. oraenv
sqlplus /nolog <<EOF
connect sys as sysdba
alter system set local_listener='LISTCDB2' scope=both;
create database link cdb1_link connect to system identified by oracle using '(DESCRIPTION = (ADDRESS = (PROTOCOL = TCP)(HOST = localhost)(PORT = 1523)) (CONNECT_DATA = (SERVER = DEDICATED) (SERVICE_NAME = cdb1)))';
grant sysoper to system container=all;
EOF
