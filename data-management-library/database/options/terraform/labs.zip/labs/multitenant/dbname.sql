conn system/oracle@localhost:1523/oe;
select name from v$database;
exit;

