conn system/oracle@localhost:1523/oe
select current_scn, to_char(sysdate, 'YYYYMMDD-HH12MISS') time from v$database;
