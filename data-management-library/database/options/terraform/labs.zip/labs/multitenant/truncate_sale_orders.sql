conn soe/soe@localhost:1523/oe
truncate table sale_orders;

