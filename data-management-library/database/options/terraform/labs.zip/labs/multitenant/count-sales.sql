connect soe/soe@localhost:1523/oe
select count(*) from sale_orders;

