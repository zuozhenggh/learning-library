ORACLE_SID=CDB1
ORAENV_ASK=NO
. oraenv
sqlplus /nolog <<EOF
connect sys as sysdba
alter system set local_listener='LISTCDB1' scope=both;

declare
    cursor DBLink_Curs is
      select DB_Link
      from DBA_DB_Links
      where Owner = 'C##SYSTEM'
      order by 1;

    cursor Public_DBLink_Curs is
      select DB_Link
      from DBA_DB_Links
      where Owner = 'PUBLIC'
      and   DB_Link in ('CDB1_DBLINK','CDB2_DBLINK')
      order by 1;

    DB_Link_Name varchar2(50);
    begin
      for DBLink_Rec in DBLink_Curs
      loop
        DB_Link_Name := DBLink_Rec.DB_Link;
        -- dbms_output.put_line('drop database link '||DB_Link_Name||';');
        execute immediate('drop database link '||DB_Link_Name);
      end loop;
      for Public_DBLink_Rec in Public_DBLink_Curs
      loop
        DB_Link_Name := Public_DBLink_Rec.DB_Link;
        -- dbms_output.put_line('drop public database link '||DB_Link_Name||';');
        execute immediate('drop public database link '||DB_Link_Name);
      end loop;
    end;
    /

alter pluggable database all close immediate;

    declare
    cursor PDB_Curs is
      select PDB_Name
      from DBA_PDBs
      where PDB_NAME not in ('PDB$SEED','PDB1','PDB2')
      and   Application_Clone = 'NO'
      order by Application_Root
      ,        PDB_Name;

    PDB_Name varchar2(50);
    begin
      for PDB_Rec in PDB_Curs
      loop
        PDB_Name := PDB_Rec.PDB_Name;
        -- dbms_output.put_line('drop pluggable database '||PDB_Name||' including datafiles;');
        execute immediate('drop pluggable database '||PDB_Name||' including datafiles');
      end loop;
    end;
    /

alter pluggable database all open;

EOF

ORACLE_SID=CDB2
ORAENV_ASK=NO
. oraenv
sqlplus /nolog <<EOF
connect sys as sysdba
alter system set local_listener='LISTCDB2' scope=both;

declare
    cursor DBLink_Curs is
      select DB_Link
      from DBA_DB_Links
      where Owner = 'C##SYSTEM'
      order by 1;

    cursor Public_DBLink_Curs is
      select DB_Link
      from DBA_DB_Links
      where Owner = 'PUBLIC'
      and   DB_Link in ('CDB1_DBLINK','CDB2_DBLINK')
      order by 1;

    DB_Link_Name varchar2(50);
    begin
      for DBLink_Rec in DBLink_Curs
      loop
        DB_Link_Name := DBLink_Rec.DB_Link;
        -- dbms_output.put_line('drop database link '||DB_Link_Name||';');
        execute immediate('drop database link '||DB_Link_Name);
      end loop;
      for Public_DBLink_Rec in Public_DBLink_Curs
      loop
        DB_Link_Name := Public_DBLink_Rec.DB_Link;
        -- dbms_output.put_line('drop public database link '||DB_Link_Name||';');
        execute immediate('drop public database link '||DB_Link_Name);
      end loop;
    end;
    /

alter pluggable database all close immediate;

    declare
    cursor PDB_Curs is
      select PDB_Name
      from DBA_PDBs
      where PDB_NAME not in ('PDB$SEED','PDB1','PDB2')
      and   Application_Clone = 'NO'
      order by Application_Root
      ,        PDB_Name;

    PDB_Name varchar2(50);
    begin
      for PDB_Rec in PDB_Curs
      loop
        PDB_Name := PDB_Rec.PDB_Name;
        -- dbms_output.put_line('drop pluggable database '||PDB_Name||' including datafiles;');
        execute immediate('drop pluggable database '||PDB_Name||' including datafiles');
      end loop;
    end;
    /

alter pluggable database all open;


EOF

