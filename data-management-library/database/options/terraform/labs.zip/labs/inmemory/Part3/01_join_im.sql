@../imlogin.sql

set pages 9999
set lines 100

set timing on
set echo on

-- In-Memory Column Store query

select
  sum(lo_extendedprice * lo_discount) revenue
from
  LINEORDER l,
  DATE_DIM d
where
  l.lo_orderdate = d.d_datekey
  and l.lo_discount between 2 and 3
  and l.lo_quantity < 24
  and d.d_date='December 24, 1996';

set echo off
set timing off

pause Hit enter ...

select * from table(dbms_xplan.display_cursor());

pause Hit enter ...

@../imstats.sql
