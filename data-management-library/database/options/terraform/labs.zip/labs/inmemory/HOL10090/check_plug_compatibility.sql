alter system flush shared_pool
/
begin
  if not
    Sys.DBMS_PDB.Check_Plug_Compatibility('/u01/app/oracle/oradata/pdb_manifests/noncdb.xml')
  then
    for r in (
      select *
      from PDB_Plug_In_Violations
      where Name = 'NONCDB' order by Time)
    loop
      DBMS_Output.Put_Line('');
      DBMS_Output.Put_Line(Rpad('-', 80, '-'));
      DBMS_Output.Put_Line('');
      DBMS_Output.Put_Line(To_Char(r.Time, 'Day dd-Mon-yyy hh24:mi'));
      DBMS_Output.Put_Line(r.Type);
      DBMS_Output.Put_Line(r.Cause);
      DBMS_Output.Put_Line('Error_Number: '||
        To_Char(r.Error_Number, '99999999'));
      DBMS_Output.Put_Line('Line: '||
        To_Char(r.Line, '99999999'));
      DBMS_Output.Put_Line(r.Message);
      DBMS_Output.Put_Line(r.Status);
      DBMS_Output. Put_Line(r.Action);
    end loop;
  end if;
  DBMS_Output.Put_Line('');
  DBMS_Output.Put_Line(Rpad('-', 80, '-'));
end;
/
