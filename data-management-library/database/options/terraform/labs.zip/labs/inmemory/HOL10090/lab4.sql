set echo off
set termout on
set serveroutput on
set feedback 0

column Pluggable_Database FORMAT A18
column "Who am I?" FORMAT A120
clear screen
----------------------------

-- Exercise 4. Plug in PDB
-- =======================

connect c##Sysdba/oracle@HoL/cdb2 AS SYSDBA

/*
@@whoami

show pdbs

begin
  if not
    Sys.DBMS_PDB.Check_Plug_Compatibility
    ('/u01/app/oracle/oradata/pdb_manifests/pdb2.xml')
  then
    Raise_Application_Error(-20000, 'Incompatible');
  end if;
end;
/
*/

create pluggable database PDB2
using '/u01/app/oracle/oradata/pdb_manifests/pdb2.xml'
move;

/*
show pdbs

@@show_cdb_files
*/

alter pluggable database PDB2 open;

/*
show pdbs
*/
