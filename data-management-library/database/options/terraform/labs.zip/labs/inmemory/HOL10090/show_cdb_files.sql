COLUMN "Con_Name" FORMAT A10
COLUMN "T'space_Name" FORMAT A12
COLUMN "File_Name" FORMAT A120

with Containers as (
  select PDB_ID Con_ID, PDB_Name Con_Name from DBA_PDBs
  union
  select 1 Con_ID, 'CDB$ROOT' Con_Name from Dual)
select
  Con_ID,
  Con_Name "Con_Name",
  Tablespace_Name "T'space_Name",
  File_Name "File_Name"
from CDB_Data_Files inner join Containers using (Con_ID)
union
select
  Con_ID,
  Con_Name "Con_Name",
  Tablespace_Name "T'space_Name",
  File_Name "File_Name"
from CDB_Temp_Files inner join Containers using (Con_ID)
order by 1, 3
/
