set echo off
set termout on
set serveroutput on
set feedback 0

column Pluggable_Database FORMAT A18
column "Who am I?" FORMAT A120
clear screen
----------------------------

-- Exercise 2. Clone PDB
-- =====================

connect c##Sysdba/oracle@HoL/cdb1 AS SYSDBA

alter pluggable database PDB1 
open read only force;

/*
show pdbs
*/

create pluggable database PDB2 from PDB1;

alter pluggable database PDB1 open force;

/*
show pdbs
*/

alter pluggable database PDB2 open;

/*
show pdbs
*/

connect PDB_Admin/oracle@Hol/pdb2

/*
select * from my_tab;
*/

