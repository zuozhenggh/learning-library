set echo off
set termout on
set serveroutput on
set feedback 0

column Pluggable_Database FORMAT A18
column "Who am I?" FORMAT A120
clear screen
----------------------------

prompt
prompt Exercise 3. Unplug PDB
prompt ======================
prompt 

prompt SQL> connect c##Sysdba/oracle@HoL/cdb1 AS SYSDBA
connect c##Sysdba/oracle@HoL/cdb1 AS SYSDBA
-- Need to do this after every connect.
set feedback 6

prompt
prompt -- In this exercise we'll unplug PDB2, which was created in Exercise 2.
prompt -- To unplug a database it must first be closed.  
prompt -- Then we can issue the unplug command.
prompt
prompt ------------------------------------------------------------------------------------------------------------------------

pause Press [Enter] to continue...

prompt SQL> alter pluggable database PDB2 close immediate
prompt SQL> /
alter pluggable database PDB2 close immediate;

prompt SQL> alter pluggable database PDB2
prompt SQL> unplug into
prompt SQL> '/u01/app/oracle/oradata/pdb_manifests/pdb2.xml'
prompt SQL> /
alter pluggable database PDB2
unplug into
'/u01/app/oracle/oradata/pdb_manifests/pdb2.xml';

prompt SQL> show pdbs
show pdbs

prompt
prompt -- We pause at this stage to view the status of the PDBs.
prompt -- Note that PDB2, which we've just unplugged, is still shown as mounted. 
prompt -- The next step is to drop the PDB from CDB1, but since we're unplugging we want to keep the datafiles
prompt
prompt ------------------------------------------------------------------------------------------------------------------------

pause Press [Enter] to continue...

prompt SQL> drop pluggable database PDB2 keep datafiles
prompt SQL> /
drop pluggable database PDB2 keep datafiles;

prompt SQL> show pdbs
show pdbs

prompt
prompt SQL> @@show_cdb_files
@@show_cdb_files

prompt -- Now we see that PDB2 and its associated files are no longer registered in CDB1.
prompt -- Finally we'll show the contents of the unplugged PDB's manifest file. 
prompt
prompt ------------------------------------------------------------------------------------------------------------------------

pause Press [Enter] to continue...

prompt SQL> host cat /u01/app/oracle/oradata/pdb_manifests/pdb2.xml
host cat /u01/app/oracle/oradata/pdb_manifests/pdb2.xml
