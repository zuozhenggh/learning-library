begin
  for r in (
    select *
    from PDB_Plug_In_Violations
    where Name = 'EXNONCDB' order by Time)
  loop
    DBMS_Output.Put_Line('');
    DBMS_Output.Put_Line(Rpad('-', 80, '-'));
    DBMS_Output.Put_Line('');
    DBMS_Output.Put_Line(To_Char(r.Time, 'Day dd-Mon-yyy hh24:mi'));
    DBMS_Output.Put_Line(r.Type);
    DBMS_Output.Put_Line(r.Cause);
    DBMS_Output.Put_Line('Error_Number: '||
      To_Char(r.Error_Number, '99999999'));
    DBMS_Output.Put_Line('Line: '||
      To_Char(r.Line, '99999999'));
    DBMS_Output.Put_Line(r.Message);
    DBMS_Output.Put_Line(r.Status);
    DBMS_Output. Put_Line(r.Action);
  end loop;
end;
/
