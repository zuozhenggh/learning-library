set echo off
set termout on
set serveroutput on
set feedback 0

column Pluggable_Database FORMAT A18
column "Who am I?" FORMAT A120
clear screen
----------------------------

prompt
prompt Exercise 6. Clone from unplugged PDB
prompt ====================================
prompt 

prompt SQL> CONNECT c##Sysdba/oracle@HoL/cdb2 AS SYSDBA
CONNECT c##Sysdba/oracle@HoL/cdb2 AS SYSDBA
-- Need to do this after every connect.
set feedback 6

prompt
prompt -- In this exercise we take two clones of an unplugged PDB. 
prompt -- This would be a typical activity in development and testing, cloning "golden master" PDBs.
prompt
prompt -- As in exercise 4, we'll first check plug compatibility.
prompt 
prompt ------------------------------------------------------------------------------------------------------------------------

pause Press [Enter] to continue...

prompt SQL> begin
prompt SQL>   if not
prompt SQL>     Sys.DBMS_PDB.Check_Plug_Compatibility
prompt SQL> ('/u01/app/oracle/oradata/gold_pdbs/sample_schemas/sample_schemas.xml')
prompt SQL>   then
prompt SQL>     Raise_Application_Error(-20000, 'Incompatible');
prompt SQL>   end if;
prompt SQL> end;
prompt SQL> /
begin
  if not
    Sys.DBMS_PDB.Check_Plug_Compatibility
('/u01/app/oracle/oradata/gold_pdbs/sample_schemas/sample_schemas.xml')
  then
    Raise_Application_Error(-20000, 'Incompatible');
  end if;
end;
/

prompt -- No news is good news here. It means that there are no incompatibilities.
prompt -- Now we plug in two clones. Note the keyword "copy", as we're cloning, not simply plugging in.
prompt
prompt ------------------------------------------------------------------------------------------------------------------------

pause Press [Enter] to continue...

prompt -- Create the first clone.
prompt

prompt SQL> create pluggable database Sample_Schemas_1 as clone
prompt SQL> using '/u01/app/oracle/oradata/gold_pdbs/sample_schemas/sample_schemas.xml'
prompt SQL> storage (maxsize unlimited max_shared_temp_size unlimited)
prompt SQL> copy
prompt SQL> /
create pluggable database Sample_Schemas_1 as clone
using '/u01/app/oracle/oradata/gold_pdbs/sample_schemas/sample_schemas.xml'
storage (maxsize unlimited max_shared_temp_size unlimited)
copy;

prompt -- Create the second clone.
prompt

prompt SQL> create pluggable database Sample_Schemas_2 as clone
prompt SQL> using '/u01/app/oracle/oradata/gold_pdbs/sample_schemas/sample_schemas.xml'
prompt SQL> storage (maxsize unlimited max_shared_temp_size unlimited)
prompt SQL> copy
prompt SQL> /
create pluggable database Sample_Schemas_2 as clone
using '/u01/app/oracle/oradata/gold_pdbs/sample_schemas/sample_schemas.xml'
storage (maxsize unlimited max_shared_temp_size unlimited)
copy;

prompt SQL> show pdbs
show pdbs

prompt
prompt -- There are the two PDBs we've just cloned (from an unplugged sample schema PDB).
prompt -- Now we must open them, which can be done in a single statement. 
prompt -- Finally, note that the two PDBs have different GUIDs. Look carefully!
prompt
prompt ------------------------------------------------------------------------------------------------------------------------

pause Press [Enter] to continue...

prompt SQL> alter pluggable database all open
prompt SQL> /
alter pluggable database all open;

prompt SQL> show pdbs
show pdbs

prompt
prompt SQL> @@show_cdb_pdb_guids
@@show_cdb_pdb_guids
