set echo off
set termout on
set serveroutput on

column Pluggable_Database FORMAT A18
column "Who am I?" FORMAT A120
clear screen
----------------------------

prompt
prompt Exercise 2. Clone PDB
prompt =====================
prompt 

prompt SQL> connect c##Sysdba/oracle@HoL/cdb1 AS SYSDBA
connect c##Sysdba/oracle@HoL/cdb1 AS SYSDBA
-- Need to do this after every connect.
set feedback 6

prompt
prompt -- In this exercise we'll clone PDB1, which was created in Exercise 1.
prompt -- To clone a database it must be open read-only. This is achieved with a single statement. 
prompt -- We then clone it and re-open again as soon as possible to minimize downtime.
prompt
prompt ------------------------------------------------------------------------------------------------------------------------

pause Press [Enter] to continue...

prompt SQL> alter pluggable database PDB1 
prompt SQL> open read only force
prompt SQL> /
alter pluggable database PDB1 
open read only force;

prompt SQL> Show pdbs
Show pdbs

prompt
prompt SQL> create pluggable database PDB2 from PDB1
prompt SQL> /
create pluggable database PDB2 from PDB1;

prompt SQL> alter pluggable database PDB1 open force
prompt SQL> /
alter pluggable database PDB1 open force;

prompt SQL> show pdbs
show pdbs

prompt
prompt -- We have just cloned PDB1 to PDB2 and we re-opened PDB1.
prompt -- Note the two PDBs shown here and their different open modes.
prompt
prompt -- Now we can open PDB2 as well.
prompt -- We'll connect to PDB2, select from my_tab (created in the clone-source in Exercise 1)
prompt -- and query the table that was created in PDB1.
prompt
prompt ------------------------------------------------------------------------------------------------------------------------

pause Press [Enter] to continue...

prompt SQL> alter pluggable database PDB2 open
prompt SQL> /
alter pluggable database PDB2 open;

prompt SQL> show pdbs
show pdbs

prompt
prompt SQL> connect PDB_Admin/oracle@Hol/pdb2
connect PDB_Admin/oracle@Hol/pdb2

prompt
prompt SQL> select * from my_tab
prompt SQL> /
select * from my_tab;

prompt
prompt -- There is the row that was created in the clone-source, PDB1.
prompt
prompt ------------------------------------------------------------------------------------------------------------------------

