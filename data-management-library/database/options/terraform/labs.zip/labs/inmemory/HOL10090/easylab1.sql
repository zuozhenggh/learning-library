set echo off
set termout on
set serveroutput on

column Pluggable_Database FORMAT A18
column "Who am I?" FORMAT A120
clear screen
----------------------------

prompt
prompt Exercise 1. Create brand-new PDB
prompt ================================
prompt 

prompt SQL> CONNECT c##Sysdba/oracle@HoL/cdb1 AS SYSDBA
CONNECT c##Sysdba/oracle@HoL/cdb1 AS SYSDBA
-- Need to do this after every connect.
set feedback 6

prompt
prompt @@whoami
@@whoami

prompt SQL> show pdbs
show pdbs

prompt
prompt -- Note "Who am I?" from above.
prompt -- Note also that there are currently no user-defined PDBs. 
prompt -- Now we are going to create our first PDB.
prompt
prompt ------------------------------------------------------------------------------------------------------------------------

pause Press [Enter] to continue...

prompt SQL> create pluggable database PDB1
prompt SQL> admin user PDB_Admin identified by oracle
prompt SQL> /
create pluggable database PDB1
admin user PDB_Admin identified by oracle;

prompt SQL> alter pluggable database PDB1 open
prompt SQL> /
alter pluggable database PDB1 open;

prompt SQL> show pdbs
show pdbs

prompt
prompt -- We have just created our first PDB and opened it! There it is!
prompt -- Now we're going to move to that new PDB and create a local DBA - a PDBA.
prompt
prompt ------------------------------------------------------------------------------------------------------------------------

pause Press [Enter] to continue...

prompt SQL> alter session set container = PDB1
prompt SQL> /
alter session set container = PDB1;

prompt SQL> grant SysDBA to PDB_Admin
prompt SQL> /
grant SysDBA to PDB_Admin;

prompt -- Now can can connect as the new PDBA and do some DBA work.
prompt -- We'll start by creating a tablespace, making it the default 
prompt -- and giving ourselves "create table" privilege in that tablespace.
prompt
prompt ------------------------------------------------------------------------------------------------------------------------

pause Press [Enter] to continue...

prompt SQL> connect PDB_Admin/oracle@HoL/pdb1 AS SYSDBA
connect PDB_Admin/oracle@HoL/pdb1 AS SYSDBA
-- Need to do this after every connect.
set feedback 6

prompt
prompt SQL> create tablespace Users
prompt SQL> datafile size 20M
prompt SQL> autoextend on next 1M maxsize unlimited
prompt SQL> segment space management auto
prompt SQL> /
create tablespace Users
datafile size 20M
autoextend on next 1M maxsize unlimited
segment space management auto;

prompt SQL> alter database default tablespace Users
prompt SQL> /
alter database default tablespace Users;

prompt SQL> grant create table, unlimited tablespace
prompt SQL> to PDB_Admin
prompt SQL> /
grant create table, unlimited tablespace
to PDB_Admin;

prompt -- Now let's reconnect (not as SYSDBA).
prompt -- We'll create a table and put some data in it.
prompt
prompt ------------------------------------------------------------------------------------------------------------------------

pause Press [Enter] to continue...

prompt SQL> connect PDB_Admin/oracle@HoL/pdb1
connect PDB_Admin/oracle@HoL/pdb1
-- Need to do this after every connect.
set feedback 6

prompt
prompt SQL> create table my_tab(my_col number)
prompt SQL> /
create table my_tab(my_col number);

prompt SQL> insert into my_tab values (1)
prompt SQL> /
insert into my_tab values (1);

prompt SQL> commit
prompt SQL> /
commit;

prompt -- Finally we'll reconnect to Root as the common SYSDBA. 
prompt -- There we can look at all the files for the CDB.
prompt -- Note the long OMF file names for the datafiles belonging to the new PDB
prompt
prompt ------------------------------------------------------------------------------------------------------------------------

pause Press [Enter] to continue...

prompt SQL> connect c##Sysdba/oracle@HoL/cdb1 AS SYSDBA
connect c##Sysdba/oracle@HoL/cdb1 AS SYSDBA
-- Need to do this after every connect.
set feedback 6

prompt
prompt SQL> @@show_cdb_files
@@show_cdb_files
