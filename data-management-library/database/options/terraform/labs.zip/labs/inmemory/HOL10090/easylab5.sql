set echo off
set termout on
set serveroutput on
set feedback 0

column Pluggable_Database FORMAT A18
column "Who am I?" FORMAT A120
clear screen
----------------------------

prompt
prompt Exercise 5. Drop PDB
prompt ====================
prompt 

prompt SQL> connect c##Sysdba/oracle@HoL/cdb2 AS SYSDBA
connect c##Sysdba/oracle@HoL/cdb2 AS SYSDBA
-- Need to do this after every connect.
set feedback 6

prompt
prompt -- In this exercise we'll drop PDB2, which is currently plugged into CDB2.
prompt -- To unplug a database it must first be closed.  
prompt -- Then we can issue the drop command. In this case we want to remove datafiles.
prompt
prompt ------------------------------------------------------------------------------------------------------------------------

pause Press [Enter] to continue...

prompt SQL> alter pluggable database PDB2 close immediate
prompt SQL> /
alter pluggable database PDB2 close immediate;

prompt SQL> drop pluggable database PDB2 including datafiles
prompt SQL> /
drop pluggable database PDB2 including datafiles;

prompt -- Now we see that PDB2 and its associated files are no longer registered in CDB2.
prompt
prompt ------------------------------------------------------------------------------------------------------------------------

pause Press [Enter] to continue...

prompt SQL> @@show_cdb_files
@@show_cdb_files

prompt SQL> show pdbs
show pdbs


