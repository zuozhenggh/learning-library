set echo off
set termout on
set serveroutput on
set feedback 0

column Pluggable_Database FORMAT A18
column "Who am I?" FORMAT A120
clear screen
----------------------------

-- Exercise 6. Clone from unplugged PDB
-- ====================================

connect c##Sysdba/oracle@HoL/cdb2 AS SYSDBA

begin
  if not
    Sys.DBMS_PDB.Check_Plug_Compatibility
('/u01/app/oracle/oradata/gold_pdbs/sample_schemas/sample_schemas.xml')
  then
    Raise_Application_Error(-20000, 'Incompatible');
  end if;
end;
/

create pluggable database Sample_Schemas_1 as clone
using '/u01/app/oracle/oradata/gold_pdbs/sample_schemas/sample_schemas.xml'
storage (maxsize unlimited max_shared_temp_size unlimited)
copy;

create pluggable database Sample_Schemas_2 as clone
using '/u01/app/oracle/oradata/gold_pdbs/sample_schemas/sample_schemas.xml'
storage (maxsize unlimited max_shared_temp_size unlimited)
copy;

show pdbs

alter pluggable database all open;

show pdbs

@@show_cdb_pdb_guids
