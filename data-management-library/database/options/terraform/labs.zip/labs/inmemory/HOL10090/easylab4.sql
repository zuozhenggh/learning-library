set echo off
set termout on
set serveroutput on
set feedback 0

column Pluggable_Database FORMAT A18
column "Who am I?" FORMAT A120
clear screen
----------------------------

prompt
prompt Exercise 4. Plug in PDB
prompt =======================
prompt 

prompt SQL> connect c##Sysdba/oracle@HoL/cdb2 AS SYSDBA
connect c##Sysdba/oracle@HoL/cdb2 AS SYSDBA
-- Need to do this after every connect.
set feedback 6

prompt
prompt @@whoami
@@whoami

prompt SQL> show pdbs
show pdbs

prompt
prompt -- Note "Who am I?" from above - we're now connected to CDB2.
prompt -- Note also that there are currently no user-defined PDBs. 
prompt -- In this exercise we'll plug PDB2 into CDB2. 
prompt -- Recall that we cloned this in CDB1 and unplugged it in previous steps.
prompt
prompt -- First we check the plug-compatibility of the unplugged PDB with CDB2.
prompt
prompt ------------------------------------------------------------------------------------------------------------------------

pause Press [Enter] to continue...

prompt SQL> begin
prompt SQL>   if not
prompt SQL>     Sys.DBMS_PDB.Check_Plug_Compatibility
prompt SQL>     ('/u01/app/oracle/oradata/pdb_manifests/pdb2.xml')
prompt SQL>   then
prompt SQL>     Raise_Application_Error(-20000, 'Incompatible');
prompt SQL>   end if;
prompt SQL> end;
prompt SQL> /
begin
  if not
    Sys.DBMS_PDB.Check_Plug_Compatibility
    ('/u01/app/oracle/oradata/pdb_manifests/pdb2.xml')
  then
    Raise_Application_Error(-20000, 'Incompatible');
  end if;
end;
/

prompt -- No news is good news here. It means that there are no incompatibilities.
prompt -- Now we plug it in. Note the keyword "move".
prompt
prompt ------------------------------------------------------------------------------------------------------------------------

pause Press [Enter] to continue...

prompt SQL> create pluggable database PDB2
prompt SQL> using '/u01/app/oracle/oradata/pdb_manifests/pdb2.xml'
prompt SQL> move
prompt SQL> /
create pluggable database PDB2
using '/u01/app/oracle/oradata/pdb_manifests/pdb2.xml'
move;

prompt SQL> show pdbs
show pdbs

prompt -- There is the successfully plugged-in PDB along with its datafiles.
prompt -- The final step is to open it for business.
prompt -- We can now see its data files. 
prompt
prompt ------------------------------------------------------------------------------------------------------------------------

pause Press [Enter] to continue...

prompt SQL> alter pluggable database PDB2 open
prompt SQL> /
alter pluggable database PDB2 open;

prompt SQL> show pdbs
show pdbs

prompt
prompt SQL> @@show_cdb_files
@@show_cdb_files

