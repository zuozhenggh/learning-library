set echo off
set termout on
set serveroutput on
set feedback 0

column Pluggable_Database FORMAT A18
column "Who am I?" FORMAT A120
clear screen
----------------------------

-- Exercise 3. Unplug PDB
-- ======================

connect c##Sysdba/oracle@HoL/cdb1 AS SYSDBA

alter pluggable database PDB2 close immediate;

alter pluggable database PDB2
unplug into
'/u01/app/oracle/oradata/pdb_manifests/pdb2.xml';

/*
show pdbs
*/

drop pluggable database PDB2 keep datafiles;

/*
show pdbs

@@show_cdb_files

host cat /u01/app/oracle/oradata/pdb_manifests/pdb2.xml
*/

