set echo off
set termout on
set serveroutput on
set feedback 0

column Pluggable_Database FORMAT A18
column "Who am I?" FORMAT A120
clear screen
----------------------------

-- Exercise 5. Drop PDB
-- ====================

connect c##Sysdba/oracle@HoL/cdb2 AS SYSDBA

alter pluggable database PDB2 close immediate;

drop pluggable database PDB2 including datafiles;

show pdbs
