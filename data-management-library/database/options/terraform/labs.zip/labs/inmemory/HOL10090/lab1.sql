set echo off
set termout on
set serveroutput on
set feedback 0

column Pluggable_Database FORMAT A18
column "Who am I?" FORMAT A120
clear screen
----------------------------

-- Exercise 1. Create brand-new PDB
-- ================================

CONNECT c##Sysdba/oracle@HoL/cdb1 AS SYSDBA

/*
@@whoami

show pdbs
*/

create pluggable database PDB1
admin user PDB_Admin identified by oracle;

alter pluggable database PDB1 open;

/*
show pdbs
*/

alter session set container = PDB1;

grant SysDBA to PDB_Admin;

connect PDB_Admin/oracle@HoL/pdb1 AS SYSDBA

create tablespace Users
datafile size 20M
autoextend on next 1M maxsize unlimited
segment space management auto;

alter database default tablespace Users;

grant create table, unlimited tablespace
to PDB_Admin;

connect PDB_Admin/oracle@HoL/pdb1

create table my_tab(my_col number);

insert into my_tab values (1);

commit;

connect c##Sysdba/oracle@HoL/cdb1 AS SYSDBA

/*
@@show_cdb_files
*/
