COLUMN "PDB Name" FORMAT A20
select PDB_Name "PDB Name", GUID
from DBA_PDBs
order by Creation_Scn
/
