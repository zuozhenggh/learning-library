ORACLE_HOME=/u01/app/oracle/product/19.3.0/db_1
export ORACLE_HOME
ORACLE_SID=imcs
export ORACLE_SID
$ORACLE_HOME/bin/lsnrctl start
$ORACLE_HOME/bin/sqlplus "/as sysdba" << EOF
startup;
exit;
EOF
exit

