@../imlogin.sql

set pages 9999
set lines 150 
set echo on

column alloc_bytes format 999,999,999,999;
column used_bytes      format 999,999,999,999;
column populate_status format a15;


-- This query displays what objects are in the In-Memory Column Store

SELECT *
FROM   v$inmemory_area;

set echo off
