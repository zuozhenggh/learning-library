@../imlogin.sql

set pages 9999
set lines 100

set timing on
set echo on

-- Buffer Cache query with the column store disabled via NO_INMEMORY hint

select /*+ NO_INMEMORY */
        lo_orderkey, lo_custkey, lo_revenue
from    LINEORDER
where   lo_orderkey = 5000000;

set echo off
set timing off

pause Hit enter ...

select * from table(dbms_xplan.display_cursor());

-- Compare the Elapsed time of the query In-Memory and in the buffer cache

pause Hit enter ...

@../imstats.sql
