@../imlogin.sql

set pages 9999
set lines 150 
column name format a20
column owner format a15
column segment_name format a30
column populate_status format a20
column bytes_in_mem format 999,999,999,999,999
column bytes_not_populated format 999,999,999,999,999

set echo on

-- Query the view v$IM_SEGMENTS to shows what objects are in the column store
-- and how much of the objects were populated. When the BYTES_NOT_POPULATED is 0 
-- it indicates the entire table was populated. 

SELECT
  v.owner,
  v.segment_name name,
  v.populate_status status,
  v.bytes bytes_in_mem,
  v.bytes_not_populated 
FROM
  v$im_segments v;

set echo off
