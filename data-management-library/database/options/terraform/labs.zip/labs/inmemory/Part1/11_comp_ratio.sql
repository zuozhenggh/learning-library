@../imlogin.sql

set pages 9999
set lines 150
column owner format a20
column name format a30
set echo on

-- This query compares the actual size of the tables on disk to the size in the 
-- In-Memory Column Store, inorder to calculate the compression ratio

SELECT v.owner,
       v.segment_name            name,  
       v.bytes                   on_disk_size, 
       v.inmemory_size           in_mem_size, 
       ROUND(v.bytes / v.inmemory_size, 2) comp_ratio 
FROM   v$im_segments v
ORDER BY 4; 

set echo off
