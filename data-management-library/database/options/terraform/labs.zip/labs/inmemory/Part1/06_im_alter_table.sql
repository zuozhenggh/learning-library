@../imlogin.sql

set pages 9999
set lines 150
set echo on

-- This query displays what objects are in the In-Memory Column Store

alter table LINEORDER inmemory;
alter table PART inmemory;
alter table CUSTOMER inmemory;
alter table SUPPLIER inmemory;
alter table DATE_DIM inmemory;

set echo off
