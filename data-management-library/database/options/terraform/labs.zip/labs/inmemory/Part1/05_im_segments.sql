@../imlogin.sql

set pages 9999
set lines 150 
column name format a30
column owner format a20
set echo on

-- This query displays what objects are in the In-Memory Column Store

select v.owner, v.segment_name name, v.populate_status status from v$im_segments v; 

set echo off
