@../imlogin.sql

set pages 9999
set lines 200
set echo on

-- Shows the SGA init.ora parameters

show parameter sga

-- Show the KEEP pool init.ora parameters

show parameter keep

-- Show the settings of all in-memory init.ora parameters

show parameter inmemory

set echo off
