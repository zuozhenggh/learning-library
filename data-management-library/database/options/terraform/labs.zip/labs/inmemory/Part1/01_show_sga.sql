@../imlogin.sql

set pages 9999
set lines 200
set echo on
set numwidth 20

-- This command shows the settings of all in-memory init.ora parameters

show sga

set echo off
