@../imlogin.sql

set pages 9999
set lines 80 
set echo on

-- This command displays the column in the view v$IM_SEGMENTS

desc v$IM_SEGMENTS

set echo off
