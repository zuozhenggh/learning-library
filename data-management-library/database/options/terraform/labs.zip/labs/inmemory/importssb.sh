export ORACLE_HOME=/u01/app/oracle/product/19c/dbhome_1; export ORACLE_BASE=/u01/app/oracle; 
ORACLE_SID=ORCL
ORAENV_ASK=NO
. oraenv
sqlplus /nolog <<EOF
connect system/Ora_DB4U@localhost:1521/orclpdb
create user ssb identified by Ora_DB4U;
grant connect, resource, dba to ssb;
grant create session to ssb;
grant unlimited tablespace to ssb;
create or replace directory import_dir as '/home/oracle';
grant read, write on directory import_dir to ssb;
EOF

impdp ssb/Ora_DB4U@localhost:1521/orclpdb schemas=SSB directory=IMPORT_DIR dumpfile=ssb.dmp logfile=ssb.log version=19.4 remap_tablespace=TS_DATA:USERS
