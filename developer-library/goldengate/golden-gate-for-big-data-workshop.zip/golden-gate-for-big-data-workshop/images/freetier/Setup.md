Update July 11, 2020

# Setup

Setup steps to create all elements required for  GGBDworkshop