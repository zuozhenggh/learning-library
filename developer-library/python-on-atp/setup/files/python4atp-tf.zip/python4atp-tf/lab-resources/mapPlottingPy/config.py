import cx_Oracle
conn_info= {
    'user': 'alpha',
    'password': 'a1phaOffice1_',
    'service_name': 'orcl4py_LOW'
}


