rm -rf weblogic-deploy
rm source.*

