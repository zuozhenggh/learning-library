
alter session set container=CDB$ROOT;
alter user system identified by YpdCNR6nua4nahj8__ container=all;
quit;