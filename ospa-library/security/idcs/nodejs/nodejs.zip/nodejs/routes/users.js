// var express = require('express');
// var router = express.Router();
//
// // Login
// //TODO: Acho que pode ser movido para o public access.
// router.get('/login', function(req, res){
// 	res.render('login');
// });
//
// module.exports = router;
